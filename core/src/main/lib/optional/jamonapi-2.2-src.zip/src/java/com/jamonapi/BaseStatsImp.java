
package com.jamonapi;

/**
 *Base class for Monitors and FrequencyDist's.  The model of having an ...Imp class
 * be between the interface and the final class allows for implementation inheritance that
 *is not possible with the public nature of interfaces.
 */


import java.util.Date;

abstract class BaseStatsImp implements BaseStats {
    
    /** Creates a new instance of BaseStatsImp */
    public BaseStatsImp() {
    }
    
  
    /** seed value to ensure that the first value always sets the max */
    static double MAX=-Double.MAX_VALUE;
    /** seed value to ensure that the first value always sets the min */
    static double MIN=Double.MAX_VALUE;
    
    /** the total for all values */
    double total=0.0; 
    /** The minimum of all values */
    double min=MIN;
    /** The maximum of all values */
    double max=MAX;
    /** The total number of occurrences/calls to this object */
    double hits=0.0;
    /** Intermediate value used to calculate std dev */
    double sumOfSquares=0.0;
    /** The most recent value that was passed to this object */
    double lastValue=0.0;
    /** The first time this object was accessed */
    long firstAccess=0;
    /** The last time this object was accessed */
    long lastAccess=0;
    /** Is this a time monitor object?  Used for performance optimizations */
    boolean isTimeMonitor=false;

  /** Calculate aggregate stas (min, max */
  public synchronized void addValue(double value) {
        
        // calculate min
        if (value < min) {
            min = value;
        }
        
        // calculate max
        if (value > max) {
            max = value;
        }
        
        // most recent value
        lastValue=value;
        
        // calculate hits i.e. n
        hits++;
        
        // calculate total i.e. sumofX's
        total+=value;
        
        // used in std deviation
        sumOfSquares+=value*value;
        
        // Being as TimeMonitors already have the current time and are passing it in
        // the value (casted as long) for last access need not be recalculated. 
        // Using this admittedly ugly approach saved about 20% performance 
        // overhead on timing monitors.
        if (!isTimeMonitor) 
           setAccessStats(System.currentTimeMillis());
       
  }
  
   public synchronized void setAccessStats(long now) {
       // set the first and last access times.
        if (firstAccess==0)
          firstAccess=now;
        
        lastAccess=now;
   
   }
      

    public synchronized void reset() {
      hits=total=sumOfSquares=lastValue=0.0;
      firstAccess=lastAccess=0;
      min=MIN;
      max=MAX;
  
    }
    
    public synchronized double getTotal() {
        return total;
    }
    public synchronized void setTotal(double value) {
        total=value;
    }
    
    public synchronized double getAvg() {
        if (hits==0.0)
            return 0.0;
        else
            return total/hits;
    }


    public synchronized double getMin() {
        return min;
    }
    public synchronized void setMin(double value) {
        min=value;
    }

        
    public synchronized double getMax() {
        return max;
    }
    public synchronized void setMax(double value) {
        max=value;
    }
    
    public synchronized double getHits() {
        return hits;
    }
    
    public synchronized void setHits(double value) {
        hits=value;
    }    

    
    public synchronized double getStdDev() {
        double stdDeviation=0;
        if (hits!=0) {
            double sumOfX=total;
            double n=hits;
            double nMinus1= (n<=1) ? 1 : n-1;  // avoid 0 divides;
            
            double numerator = sumOfSquares-((sumOfX*sumOfX)/n);
            stdDeviation=java.lang.Math.sqrt(numerator/nMinus1);
        }
        
        return stdDeviation;
    }
    
    
   public synchronized void setFirstAccess(Date date) {
       firstAccess=date.getTime();
   }
   
   
   public synchronized Date getFirstAccess() {
       return new Date(firstAccess);
   }
   
   
   public  synchronized void setLastAccess(Date date) {
       lastAccess=date.getTime();
   }
   
   
   public synchronized Date getLastAccess() {
       return new Date(lastAccess);
   }
   
    
    public synchronized double getLastValue() {
        return lastValue;
    }
    
    public synchronized void setLastValue(double value) {
        lastValue=value;
    }
    
       




}
