
package com.jamonapi;

/**
 * Simple thread safe counter class used to track activity stats 
 *
 * Created on December 16, 2005, 9:11 PM
 */


/**
 *
 * @author  ssouza 
 */
final class Counter {
    
    double count;
       
    synchronized void setCount(double value) {
        count=value;
    }
    
    synchronized double getCount() {
        return count;
    }
    
}
