package com.jamonapi;

/*
 * RowData.java
 *
 * Created on January 14, 2006, 7:37 PM 
 */




import java.util.List;

/** Used to implement getting data from monitors and frequencyDist. Purely
 * an interface of implementation details of no interest to the end user */


interface RowData {
     public List getBasicHeader(List header);
     public List getHeader(List header);
     public List getDisplayHeader(List header);
         
     public List getRowData(List rowData); 
     public List getBasicRowData(List rowData); 
     public List getRowDisplayData(List rowData);
}
