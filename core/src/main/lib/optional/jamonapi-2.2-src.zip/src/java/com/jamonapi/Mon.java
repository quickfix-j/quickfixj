package com.jamonapi;

/**
 * Monitor class that does all the tracking of stats.
 *
 * TempMon.java 
 *  2443 before removing redundancy of calls.

 */


/**
 *
 * @author  ssouza
 */
class Mon extends MonitorImp {
    private double maxActive=0.0;
    private double totalActive=0.0;
    private boolean isPrimary=false;
    private boolean initializeActivityTracking=true;
    ActivityStats activityStats;

        
    Mon(MonKey key, RangeImp range, ActivityStats activityStats, boolean isTimeMonitor) {
        this.key=key;
        this.range=range;
        this.activityStats=activityStats;
        this.isTimeMonitor=isTimeMonitor;
        
    }
    

  public Monitor start() {
       // all monitors of any type increment active
        synchronized (activityStats.allActive) {
            activityStats.allActive.count++;
        }

        // primary monitor increment active
        if (isPrimary) {
           synchronized (activityStats.primaryActive) {
              activityStats.primaryActive.count++;
           }
        }
        // tracking current active/avg active/max active for this instance
        double active;
        synchronized (activityStats.thisActive) {
            active = ++activityStats.thisActive.count;
        }
        
        synchronized (this) {
          totalActive+=active;// allows us to track the average active for THIS instance.
          if (active>maxActive) 
            maxActive=active;
        }
        
        // The only way activity tracking need be done is if start has been entered.
        if (initializeActivityTracking) {
          initializeActivityTracking=false;
          range.setActivityTracking(true);
        }
          
        
        return this;

  }

  public Monitor stop() {
        synchronized (activityStats.thisActive) {
            activityStats.thisActive.count--;
        }

        if (isPrimary) { // see should i use ints or longs.  what about checking for>0 before decrement??????
          synchronized (activityStats.primaryActive) {
            activityStats.primaryActive.count--;
          }          
        }
        
        synchronized (activityStats.allActive) {
            activityStats.allActive.count--;
        }       
        return this;
  }
    
  public Monitor add(double value) {
      addValue(value);
      range.add(value);
      return this;
        
  }

  
    public synchronized void reset() {
      super.reset();
      maxActive=totalActive=0.0;
      activityStats.thisActive.setCount(0);
      range.reset();
  
    }

    
    public synchronized Range getRange() {
        return range;
    }
    

  
    public synchronized double getActive() {
        return activityStats.thisActive.count;
    }

    public synchronized void setActive(double value) {
        activityStats.thisActive.setCount(value);
    }    
    

    public synchronized double getMaxActive() {
        return maxActive;
    }
    
    public synchronized void setMaxActive(double value) {
        maxActive=value;
    }
    
    /** Neeed to reset this to 0.0 to remove avg active numbers */
    public synchronized void setTotalActive(double value) {
        totalActive=value;
    }
    
    // calculated
    public synchronized double getAvgActive() {
       if (hits==0)
          return 0;
        else
          return totalActive/hits;
    }
    
    
  
    
    public synchronized boolean isPrimary() {
        return isPrimary;
    }    
    
    public synchronized void setPrimary(boolean isPrimary) {
        this.isPrimary=isPrimary;
    }  

    
    public String toString() {
        // This character string is about 275 characters now, but made
        // the default a little bigger, so the JVM doesn't have to grow
        // the StringBuffer should I add more info.
        StringBuffer b=new StringBuffer(400);
        
        b.append(getMonKey()+": (Hits=");
        b.append(getHits());

        b.append(", Avg=");
        b.append(getAvg());
        
        b.append(", Total=");
        b.append(getTotal());
        
        b.append(", Min=");
        b.append(getMin());
        
        b.append(", Max=");
        b.append(getMax());
        
        b.append(", Active=");
        b.append(getActive());

        b.append(", Avg Active=");
        b.append(getAvgActive());

        b.append(", Max Active=");
        b.append(getMaxActive());

        b.append(", First Access=");
        b.append(getFirstAccess());

        b.append(", Last Access=");
        b.append(getLastAccess());
        b.append(")");

        return b.toString();
      
        
    }
       
    
    /** disable doesn't do anything in this class and it doesn't need to be 
     *called directly
     **/
    public void disable() {
        
    }    
  

    /** enable doesn't do anything in this class and it doesn't need to be 
     * called directly
     **/    
    public void enable() {
    }    
    
    /** This monitor can't be disabled, so it always returns true */
    public boolean isEnabled() {
        return true;
    }
    



    
}
