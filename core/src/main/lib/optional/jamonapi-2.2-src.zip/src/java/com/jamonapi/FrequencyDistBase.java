package com.jamonapi;

/**
 * Base class for FrequencyDists 
 */




import java.text.*;
import com.jamonapi.utils.*;

class FrequencyDistBase extends FrequencyDistImp {
    
        private ActivityStats activityStats;
        private double  allActiveTotal;  // used to calculate the average active total monitors for this distribution
        private double  primaryActiveTotal;
        private double  thisActiveTotal;

    
    /** Creates a new instance of FrequencyDistBase */
    public FrequencyDistBase(String displayHeader, double endValue, String name) {
        this.displayHeader=displayHeader;
        this.endValue=endValue;
        this.name=name;
   
    }
    
    public void addValue(double value) {
      super.addValue(value);
      
      // tracking activity is only done if start was called on the monitor
      // there is no need to synchronize and perform activity tracking if this
      // monitor doesn't have a start and stop called.
      if (trackActivity) {
      // note each of these objects must be synchronized as other objects/threads may also change their values.
        synchronized (activityStats.thisActive) {
           thisActiveTotal+=activityStats.thisActive.count;  // total of this monitors active  
        }      
      
        synchronized (activityStats.primaryActive) {
           primaryActiveTotal+=activityStats.primaryActive.count;  // total of primary monitors active  
        }    
      
        synchronized (activityStats.allActive) {
           allActiveTotal+=activityStats.allActive.count;  // total of all monitors active  
        }
      }
  
    }




    private double avg(double value) {
      if (hits==0)
         return 0;
      else
         return value/hits;
        
    }
     
    
    public synchronized void reset() {
       super.reset();
       allActiveTotal=primaryActiveTotal=thisActiveTotal=0;
    }
    
    public void setActivityStats(ActivityStats activityStats) {
        this.activityStats=activityStats;
    }
    
    
    public synchronized double getAvgActive() {
        return avg(thisActiveTotal);
    }    
    
    public synchronized double getAvgGlobalActive() {
        return avg(allActiveTotal);
    }    
    
    public synchronized double getAvgPrimaryActive() {
        return avg(primaryActiveTotal);
    }    
    
    private String format(double value) {
        DecimalFormat decimalFormat=LocaleContext.getFloatingPointFormatter();
        return decimalFormat.format(value);
    }

    public String toString()        {
            if (hits==0)
                return "";
            else {
                StringBuffer buff=new StringBuffer();
                buff.append(format(getHits()));
                buff.append("/");
                buff.append(format(getAvg()));
                buff.append(" (");
                buff.append(format(getAvgActive())).append("/");
                buff.append(format(getAvgPrimaryActive())).append("/");
                buff.append(format(getAvgGlobalActive())).append(")");
                
                return buff.toString();
                
            }
                
        }
    
 
}
