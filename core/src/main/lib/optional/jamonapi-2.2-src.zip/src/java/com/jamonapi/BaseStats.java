package com.jamonapi;

/**
* The interface that is implemented both by Monitors and FrequencyDist (i.e. the elements
 * of ranges). Kind of the work horse interface of JAMon.
 * *
 * @author  ssouza 
 */



import java.util.Date;


 interface BaseStats {
  
  /** reset all values in the monitor to their defaults */
  public void reset();
  
  public double getTotal();
  public void setTotal(double value);
  public double getAvg();
  public double getMin();
  public void setMin(double value);
  public double getMax();
  public void setMax(double value);
  public double getHits();
  public void setHits(double value);
  public double getStdDev();
  public void setFirstAccess(Date date);
  public Date getFirstAccess();
  public void setLastAccess(Date date);
  public Date getLastAccess();
  public double getLastValue();
  public void setLastValue(double value);
      
}
