
package com.jamonapi;

/**
 * Used to interact with monitor objects.  I would have preferred to make this an 
 *interface, but didn't do that as jamon 1.0 code would have broken.  Live and learn
 *
 * Created on December 11, 2005, 10:19 PM
 */






// Note this was done as an empty abstract class so a recompile isn't needed
// to go to jamon 2.0.  I had originally tried to make Monitor an interface.
public abstract class Monitor extends BaseStatsImp implements MonitorInt {
    
    protected MonKey key;
    
    public MonKey getMonKey() {
      return key;
    }    
 
    /** Returns the label for the monitor */
    public String getLabel() {
        return (String) key.getValue(MonKey.LABEL_HEADER);
    }
      
    /** Returns the units for the monitor */
    public String getUnits() {
        return (String) key.getValue(MonKey.UNITS_HEADER);
    }
  
}
