package com.jamonapi.proxy;


import java.lang.reflect.*;
import java.sql.SQLException;
import java.util.*;

import com.jamonapi.Monitor;
import com.jamonapi.MonitorFactory;


/** 
 * By using this proxy class ANY java interface can be monitored for performance and exceptions via JAMon.
 * In particular the 'monitor' method is great for wrapping (and so monitoring) any of the JDBC classes which
 * all implement interfaces (i.e. Connection, ResultSet, Statement, PreparedStatement,...).  It tracks performance
 * stats (hits/avg/min/max/...) for method calls and Exceptions.
 * 
 * Sample code:
 *   ResultSet rs= MonProxyFactory.monitor(resultSet);
 *   Connection conn=MonProxyFactory.monitor(connection);
 *   MyInterface my=(MyInterface) MonProxyFactory.monitor(myObject);//myObject implements MyInterface
 *   YourInterface your=(YourInterface) MonProxyFactory.monitor(yourObject);//myObject implements MyInterface
 *
 * Subsequent public method calls on this interface will be monitored.  Quite cool.   If the proxy is disabled
 * the Object will be returned unchanged.
 * 
 * Note the object passed MUST implement an interface or a runtime exception will occur i..e it can't be a 
 * plain java object.
 *
 *
 *
 */
class MonProxy implements InvocationHandler {

    private Object monitoredObj;// underlying object
    private String className;// class name of monitored object
            Params params;// parameters associated with monitoring
       
      MonProxy(Object monitoredObj, Params params) {
          this.monitoredObj = monitoredObj;
          this.params=params;
          this.className="(class="+monitoredObj.getClass().getName()+")";       
      }
 
    /** Return the underlying object being Monitored */
    public Object getMonitoredObject() {
    	 return monitoredObj;
     }
     



     /** Method that monitors method invocations of the proxied interface.  This method is not explicitly called.  
      *  The MonProxy class automatically calls it. 
      *  
      *  
      */
      public Object invoke(Object proxy, Method method,  Object[] args) throws Throwable {

    	Monitor mon=null;
        boolean isExceptionSummaryEnabled=(params.isExceptionSummaryEnabled && params.isEnabled);// track jamon stats for Exceptions?
        boolean isExceptionDetailEnabled=(params.isExceptionDetailEnabled && params.isEnabled);// save detailed stack trace in the exception buffer?
        // Because this monitor string is created every time I use a StringBuffer as it may be more effecient.
        // I didn't do this in the exception part of the code as they shouldn't be called as often.
        if (params.isInterfaceEnabled && params.isEnabled)
    	  mon=MonitorFactory.start(new StringBuffer().append("MonProxy-Interface ").append(className).append(": ").append(method.toString()).toString());
        
        try {
           return method.invoke(monitoredObj, args);// executes underlying interfaces method;
        } catch (InvocationTargetException e) {

          if (isExceptionSummaryEnabled || isExceptionDetailEnabled){
            String sqlMessage="";
            Throwable rootCause=e.getCause();
            
            // Add special info if it is a SQLException
            if (rootCause instanceof SQLException  && isExceptionSummaryEnabled) {
              SQLException sqlException=(SQLException) rootCause;
              sqlMessage=",ErrorCode="+sqlException.getErrorCode()+",SQLState="+sqlException.getSQLState();
            }
               
            if (isExceptionSummaryEnabled) {
              // Add jamon entries for Exceptions
              MonitorFactory.add("MonProxy-Exception: InvocationTargetException","Exception",1); //counts total exceptions
              MonitorFactory.add("MonProxy-Exception: Root cause exception="+rootCause.getClass().getName()+sqlMessage,"Exception",1); // Message for the exception
              MonitorFactory.add("MonProxy-Exception: "+className+" Exception: "+method.toString(),"Exception",1); // Exception and method that threw it.
            }
            
            
            // Add stack trace to buffer if it is enabled.
            if (isExceptionDetailEnabled) 
               params.exceptionBuffer.addRow(new Object[] {new Long(++params.exceptionID), new Date(), getExceptionTrace(rootCause), method.toString(), });
          } // end if (enabled)           
          
          throw e.getCause();

        } finally {
          if (mon!=null)
           mon.stop();
        }
      }

 	 // Return Exception information as a row (1 dim array)
 	 String getExceptionTrace(Throwable exception) {
 		 
 		 // each line of the stack trace will be returned in the array.
 		 StackTraceElement elements[] = exception.getStackTrace();
 		 StringBuffer trace=new StringBuffer().append(exception).append("\n");
 		 
 		 for (int i=0; i<elements.length; i++) {
 			 trace.append(elements[i]).append("\n");
 		 }

          return trace.toString(); 
 	 }      

}
